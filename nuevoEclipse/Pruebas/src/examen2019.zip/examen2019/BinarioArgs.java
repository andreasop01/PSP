package examen2019;

public class BinarioArgs {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(Integer.toBinaryString(Integer.parseInt(args[0])));


	}

}
