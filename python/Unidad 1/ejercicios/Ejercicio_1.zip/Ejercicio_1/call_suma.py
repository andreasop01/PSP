import subprocess

subprocess.run(["python","suma.py","3","4"])




