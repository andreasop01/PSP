import sys

n1=int(sys.argv[1])
n2=int(sys.argv[2])

suma=n1+n2

print(f"La suma es: {suma}")